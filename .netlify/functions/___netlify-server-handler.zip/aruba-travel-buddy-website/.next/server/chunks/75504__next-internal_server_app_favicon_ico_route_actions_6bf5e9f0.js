module.exports=[66287,(e,o,d)=>{}];

//# sourceMappingURL=75504__next-internal_server_app_favicon_ico_route_actions_6bf5e9f0.js.map