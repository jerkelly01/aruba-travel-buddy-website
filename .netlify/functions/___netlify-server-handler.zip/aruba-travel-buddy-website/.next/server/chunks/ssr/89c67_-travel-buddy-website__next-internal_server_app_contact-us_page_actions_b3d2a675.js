module.exports=[86658,(a,b,c)=>{}];

//# sourceMappingURL=89c67_-travel-buddy-website__next-internal_server_app_contact-us_page_actions_b3d2a675.js.map