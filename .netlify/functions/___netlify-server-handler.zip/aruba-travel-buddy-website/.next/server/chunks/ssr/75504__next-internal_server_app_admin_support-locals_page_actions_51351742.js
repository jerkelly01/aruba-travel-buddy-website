module.exports=[95819,(a,b,c)=>{}];

//# sourceMappingURL=75504__next-internal_server_app_admin_support-locals_page_actions_51351742.js.map