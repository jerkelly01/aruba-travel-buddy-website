module.exports=[22334,(a,b,c)=>{}];

//# sourceMappingURL=cf479_ba-travel-buddy-website__next-internal_server_app_features_page_actions_d30e6a78.js.map