module.exports=[23009,(a,b,c)=>{}];

//# sourceMappingURL=75504__next-internal_server_app_privacy-policy_page_actions_bdf3b298.js.map