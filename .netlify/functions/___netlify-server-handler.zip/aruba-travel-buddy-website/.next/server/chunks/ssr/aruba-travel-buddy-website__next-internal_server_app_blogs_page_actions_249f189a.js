module.exports=[74914,(a,b,c)=>{}];

//# sourceMappingURL=aruba-travel-buddy-website__next-internal_server_app_blogs_page_actions_249f189a.js.map