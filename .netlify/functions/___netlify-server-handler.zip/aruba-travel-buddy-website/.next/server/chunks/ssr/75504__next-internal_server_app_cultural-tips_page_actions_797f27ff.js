module.exports=[32824,(a,b,c)=>{}];

//# sourceMappingURL=75504__next-internal_server_app_cultural-tips_page_actions_797f27ff.js.map