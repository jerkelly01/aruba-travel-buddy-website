module.exports=[92633,(a,b,c)=>{}];

//# sourceMappingURL=75504__next-internal_server_app_admin_photo-challenges_page_actions_e14364f7.js.map