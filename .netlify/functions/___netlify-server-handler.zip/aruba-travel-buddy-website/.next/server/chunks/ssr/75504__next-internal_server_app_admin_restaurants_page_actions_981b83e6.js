module.exports=[85672,(a,b,c)=>{}];

//# sourceMappingURL=75504__next-internal_server_app_admin_restaurants_page_actions_981b83e6.js.map