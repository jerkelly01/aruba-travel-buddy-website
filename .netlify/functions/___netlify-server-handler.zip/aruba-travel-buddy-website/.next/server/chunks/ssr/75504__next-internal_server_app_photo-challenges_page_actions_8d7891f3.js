module.exports=[14199,(a,b,c)=>{}];

//# sourceMappingURL=75504__next-internal_server_app_photo-challenges_page_actions_8d7891f3.js.map