module.exports=[89503,(a,b,c)=>{}];

//# sourceMappingURL=75504__next-internal_server_app_admin_analytics_page_actions_7105b922.js.map