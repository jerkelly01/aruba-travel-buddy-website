module.exports=[92640,(a,b,c)=>{}];

//# sourceMappingURL=75504__next-internal_server_app_admin_transportation_page_actions_80467379.js.map