module.exports=[3038,(a,b,c)=>{}];

//# sourceMappingURL=75504__next-internal_server_app_private-transportation_page_actions_967d9dae.js.map