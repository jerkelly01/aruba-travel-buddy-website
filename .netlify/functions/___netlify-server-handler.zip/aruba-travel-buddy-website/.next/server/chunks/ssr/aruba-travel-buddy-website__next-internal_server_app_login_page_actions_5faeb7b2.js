module.exports=[84146,(a,b,c)=>{}];

//# sourceMappingURL=aruba-travel-buddy-website__next-internal_server_app_login_page_actions_5faeb7b2.js.map