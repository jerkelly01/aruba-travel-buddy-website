module.exports=[58491,(a,b,c)=>{}];

//# sourceMappingURL=75504__next-internal_server_app_terms-and-conditions_page_actions_77842873.js.map