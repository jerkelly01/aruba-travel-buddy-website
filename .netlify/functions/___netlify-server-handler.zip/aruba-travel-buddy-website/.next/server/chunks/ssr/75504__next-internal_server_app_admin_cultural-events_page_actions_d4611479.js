module.exports=[21955,(a,b,c)=>{}];

//# sourceMappingURL=75504__next-internal_server_app_admin_cultural-events_page_actions_d4611479.js.map