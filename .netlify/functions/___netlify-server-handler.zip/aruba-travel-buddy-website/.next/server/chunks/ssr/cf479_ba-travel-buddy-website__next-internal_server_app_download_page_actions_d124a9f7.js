module.exports=[31864,(a,b,c)=>{}];

//# sourceMappingURL=cf479_ba-travel-buddy-website__next-internal_server_app_download_page_actions_d124a9f7.js.map