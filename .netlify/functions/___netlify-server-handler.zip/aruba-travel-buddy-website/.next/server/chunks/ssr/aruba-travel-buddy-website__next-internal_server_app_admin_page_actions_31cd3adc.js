module.exports=[26837,(a,b,c)=>{}];

//# sourceMappingURL=aruba-travel-buddy-website__next-internal_server_app_admin_page_actions_31cd3adc.js.map