module.exports=[65140,(a,b,c)=>{}];

//# sourceMappingURL=129eb_travel-buddy-website__next-internal_server_app_admin_tours_page_actions_d752adf3.js.map