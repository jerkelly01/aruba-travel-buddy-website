module.exports=[94420,(a,b,c)=>{}];

//# sourceMappingURL=75504__next-internal_server_app_become-a-partner_page_actions_d15c5bd7.js.map