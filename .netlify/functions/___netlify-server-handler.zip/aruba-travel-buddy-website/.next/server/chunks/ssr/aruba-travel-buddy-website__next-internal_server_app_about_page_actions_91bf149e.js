module.exports=[71985,(a,b,c)=>{}];

//# sourceMappingURL=aruba-travel-buddy-website__next-internal_server_app_about_page_actions_91bf149e.js.map