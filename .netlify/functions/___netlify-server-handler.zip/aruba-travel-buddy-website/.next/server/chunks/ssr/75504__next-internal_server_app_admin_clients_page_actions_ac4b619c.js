module.exports=[66096,(a,b,c)=>{}];

//# sourceMappingURL=75504__next-internal_server_app_admin_clients_page_actions_ac4b619c.js.map