module.exports=[83500,(a,b,c)=>{}];

//# sourceMappingURL=75504__next-internal_server_app_support-locals_page_actions_82cb0430.js.map