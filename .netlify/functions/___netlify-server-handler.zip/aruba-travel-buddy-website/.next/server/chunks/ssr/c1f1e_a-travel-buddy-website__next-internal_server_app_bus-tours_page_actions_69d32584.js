module.exports=[64369,(a,b,c)=>{}];

//# sourceMappingURL=c1f1e_a-travel-buddy-website__next-internal_server_app_bus-tours_page_actions_69d32584.js.map