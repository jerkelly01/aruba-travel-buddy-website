module.exports=[61504,(a,b,c)=>{}];

//# sourceMappingURL=75504__next-internal_server_app__global-error_page_actions_b8fadb1c.js.map