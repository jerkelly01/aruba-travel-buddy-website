module.exports=[55028,a=>{a.v("/_next/static/media/favicon.aabd12e2.ico")},82797,a=>{"use strict";let b={src:a.i(55028).default,width:32,height:32};a.s(["default",0,b])}];

//# sourceMappingURL=aruba-travel-buddy-website_src_app_6ba159af._.js.map