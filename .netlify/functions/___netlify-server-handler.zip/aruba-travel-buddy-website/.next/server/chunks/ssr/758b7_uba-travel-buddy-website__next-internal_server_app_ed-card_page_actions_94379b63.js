module.exports=[25112,(a,b,c)=>{}];

//# sourceMappingURL=758b7_uba-travel-buddy-website__next-internal_server_app_ed-card_page_actions_94379b63.js.map