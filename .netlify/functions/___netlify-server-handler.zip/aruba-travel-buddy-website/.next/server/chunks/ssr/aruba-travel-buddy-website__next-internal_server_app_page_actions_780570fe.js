module.exports=[71555,(a,b,c)=>{}];

//# sourceMappingURL=aruba-travel-buddy-website__next-internal_server_app_page_actions_780570fe.js.map