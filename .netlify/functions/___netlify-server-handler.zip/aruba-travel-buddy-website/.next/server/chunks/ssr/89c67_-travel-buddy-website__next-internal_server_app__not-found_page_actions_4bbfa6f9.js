module.exports=[18681,(a,b,c)=>{}];

//# sourceMappingURL=89c67_-travel-buddy-website__next-internal_server_app__not-found_page_actions_4bbfa6f9.js.map