module.exports=[2035,(a,b,c)=>{}];

//# sourceMappingURL=129eb_travel-buddy-website__next-internal_server_app_car-rentals_page_actions_44e1f152.js.map