module.exports=[26243,(a,b,c)=>{}];

//# sourceMappingURL=129eb_travel-buddy-website__next-internal_server_app_restaurants_page_actions_45d954d1.js.map