var R=require("../../chunks/[turbopack]_runtime.js")("server/app/favicon.ico/route.js")
R.c("server/chunks/[root-of-the-server]__a6d89067._.js")
R.c("server/chunks/[root-of-the-server]__f92daa2e._.js")
R.c("server/chunks/75504__next-internal_server_app_favicon_ico_route_actions_6bf5e9f0.js")
R.m(46475)
module.exports=R.m(46475).exports
