globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/8b79c73694bef8df.js",
    "static/chunks/f8a68087a5928925.js",
    "static/chunks/e6db3edc6819c833.js",
    "static/chunks/779ba6b35bcf9ffa.js",
    "static/chunks/0b8e76647d9be4c0.js",
    "static/chunks/turbopack-aa36608ef023d339.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];