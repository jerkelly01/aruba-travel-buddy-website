globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/f246d8ea9b589cc1.js",
    "static/chunks/f8a68087a5928925.js",
    "static/chunks/0b8e76647d9be4c0.js",
    "static/chunks/c46f03ab0321be7d.js",
    "static/chunks/e6db3edc6819c833.js",
    "static/chunks/turbopack-962896339ec29e68.js"
  ]
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js"
];